# Este es un módulo con funciones que despiden
def despedirse():
	print("Adiós, me estoy despidiendo desde la función despedirse del módulo despedidas")

class Despedida():
	def __init__(self):
		print("Adiós, me estoy despidiendo desde el init de la clase Despedida")