from setuptools import setup

setup(
	name = "paquete",
	version = "0.1",
	description = "Este es un paquete ejemplo",
	author = "Eloy Jimenez",
	autor_email = "polo@hotmail.com",
	url = "http://ejimenez.info",
	scripts = [],
	packages = ["paquete","paquete.adios","paquete.hola"]
)

